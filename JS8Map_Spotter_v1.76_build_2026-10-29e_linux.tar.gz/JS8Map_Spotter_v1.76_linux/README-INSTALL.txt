JS8Map Spotter 1.76 for Linux
=============================

Installs alongside JS8Map 1.75 and does not change it.

TO INSTALL
----------
1. Open a terminal in this folder.
2. Type:    ./install.sh
3. Press Enter.

That is all. No root password is needed. Everything is installed inside
your own home folder.

When it finishes you will have JS8Map Spotter in your applications menu and an
icon on your desktop.


BEFORE YOU RUN IT
-----------------
In JS8Call, open File > Settings > Reporting and set
TCP Max Connections to 4. JS8Call ships with this set to 1, and at 1 the
map cannot get its own connection.


THE MAP WORKS OFFLINE
---------------------
No map key is needed and no internet connection is needed for the map to
draw. Coastlines, borders, state and province lines, lakes, place names
and stations all draw with the network off. Street-level detail is the
only thing that needs a connection, and it is optional.


TO REMOVE IT
------------
Open a terminal in this folder and type:    ./uninstall.sh

Your settings and logs are left alone.
