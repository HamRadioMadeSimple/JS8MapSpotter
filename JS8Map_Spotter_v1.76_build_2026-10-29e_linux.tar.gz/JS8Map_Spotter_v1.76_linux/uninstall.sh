#!/bin/bash
# ============================================================================
#  JS8Map Spotter uninstaller for Linux (JS8Map 1.75 is not touched)
#
#  Run:   ./uninstall.sh
#
#  Removes the installed program and its launchers.
#  Your settings and databases are NOT touched.
# ============================================================================

set -e

APPDIR="${HOME}/.local/lib/JS8MapSpotter"
MENUDIR="${HOME}/.local/share/applications"
DESKDIR="$(xdg-user-dir DESKTOP 2>/dev/null || echo "${HOME}/Desktop")"
DATADIR="${XDG_DATA_HOME:-${HOME}/.local/share}/JS8Map Spotter"

echo "This will remove:"
echo "    ${APPDIR}"
echo "    ${MENUDIR}/js8map-spotter.desktop"
echo "    ${MENUDIR}/js8map-spotter-map.desktop"
echo "    ${DESKDIR}/JS8Map-Spotter.desktop"
echo ""
echo "Your settings and databases are in a separate folder:"
echo "    ${DATADIR}"
echo "That folder will NOT be touched."
echo ""
printf "Type YES to continue: "
read -r ANSWER

# Accept y / yes / YES and anything between. The old test was an exact match on
# "YES", so a lower-case "yes" silently cancelled -- safe, but every new
# operator hits it once.
case "$ANSWER" in
    [Yy]|[Yy][Ee][Ss]) ;;
    *)
        echo "Nothing was removed."
        exit 0
        ;;
esac

rm -rf "${APPDIR}"
rm -f "${MENUDIR}/js8map-spotter.desktop" "${MENUDIR}/js8map-spotter-map.desktop"
rm -f "${DESKDIR}/JS8Map-Spotter.desktop"
update-desktop-database "${MENUDIR}" 2>/dev/null || true

echo ""
echo "DONE. JS8Map Spotter has been removed."
echo ""
