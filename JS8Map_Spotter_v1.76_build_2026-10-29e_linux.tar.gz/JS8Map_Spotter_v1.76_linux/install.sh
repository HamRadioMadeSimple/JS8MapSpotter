#!/bin/bash
# ============================================================================
#  JS8Map Spotter installer for Linux
#  Installs ALONGSIDE JS8Map 1.75 and never changes it.
#
#  Run:   ./install.sh
#
#  Installs to your own home folder. No root and no sudo needed.
#  Nothing is written outside your home folder.
# ============================================================================

set -e

APPDIR="${HOME}/.local/lib/JS8MapSpotter"
MENUDIR="${HOME}/.local/share/applications"
DESKDIR="$(xdg-user-dir DESKTOP 2>/dev/null || echo "${HOME}/Desktop")"
SRC="$(cd "$(dirname "$0")" && pwd)"

MAPFILES="leaflet.js leaflet.css js8map_borders.json js8map_admin1.json js8map_lakes.json js8map_places.json"

DATADIR="${XDG_DATA_HOME:-${HOME}/.local/share}/JS8Map Spotter"

echo "============================================================"
echo " Installing JS8Map Spotter"
echo "============================================================"
echo ""

# --- never install on top of the app's own data folder ----------------------
#     ~/.local/share/JS8Map Spotter is where Spotter keeps settings, databases and the
#     browser scratch folder. The program must not be unpacked into it.
if [ "${APPDIR}" = "${DATADIR}" ]; then
    echo "STOP: the install folder and the data folder are the same."
    echo "      Nothing has been installed."
    exit 1
fi
for marker in ham_map_config.json js8_spots.db js8_relay.db map_window_profile; do
    if [ -e "${APPDIR}/${marker}" ]; then
        echo "STOP: ${APPDIR}"
        echo "      already holds JS8Map settings or databases."
        echo "      The program must not be installed on top of them."
        echo "      Nothing has been installed."
        exit 1
    fi
done

# --- check the package is complete before touching anything -----------------
if [ ! -f "${SRC}/JS8Map" ]; then
    echo "STOP: the JS8Map program is missing from this folder."
    echo "      Unpack the whole .tar.gz and run install.sh from inside it."
    exit 1
fi

MISSING=""
for f in $MAPFILES; do
    if [ ! -f "${SRC}/${f}" ]; then
        MISSING="${MISSING} ${f}"
    fi
done
# build_canadian_db.py is required too -- the Canadian step of the first-run
# wizard runs it, and looks for it beside the program.
if [ ! -f "${SRC}/build_canadian_db.py" ]; then
    MISSING="${MISSING} build_canadian_db.py"
fi
if [ -n "$MISSING" ]; then
    echo "STOP: this package is incomplete. Missing:"
    for f in $MISSING; do echo "        ${f}"; done
    echo "      Nothing has been installed."
    exit 1
fi

# --- copy the program and the six map files, side by side -------------------
mkdir -p "${APPDIR}"
cp "${SRC}/JS8Map" "${APPDIR}/JS8Map"
chmod 755 "${APPDIR}/JS8Map"

for f in $MAPFILES; do
    cp "${SRC}/${f}" "${APPDIR}/${f}"
done

# the Canadian database builder, beside the program where js8map_fcc.py looks
cp "${SRC}/build_canadian_db.py" "${APPDIR}/build_canadian_db.py"

ICON_LINE=""
if [ -f "${SRC}/js8map-spotter.png" ]; then
    cp "${SRC}/js8map-spotter.png" "${APPDIR}/js8map-spotter.png"
    ICON_LINE="Icon=${APPDIR}/js8map-spotter.png"
fi

echo "Installed to: ${APPDIR}"

# --- build the launcher -----------------------------------------------------
make_launcher () {
    TARGET="$1"
    cat > "${TARGET}" <<DESKTOP_EOF
[Desktop Entry]
Type=Application
Version=1.0
Name=JS8Map Spotter
GenericName=JS8Call Map
Comment=StatReps, MCForms and QSOs heard on JS8Call, on a map
Exec="${APPDIR}/JS8Map"
Path=${APPDIR}
${ICON_LINE}
Terminal=false
Categories=Network;HamRadio;
StartupNotify=true
StartupWMClass=Js8mapspotter
DESKTOP_EOF
    chmod +x "${TARGET}"
}

# applications menu -- Spotter's OWN file names (same as
# tools/install_linux_launcher.sh). JS8Map 1.75's js8map.desktop is left alone.
mkdir -p "${MENUDIR}"
make_launcher "${MENUDIR}/js8map-spotter.desktop"

# hidden entry for the map window, so the taskbar shows the sharp logo
# (Chromium gives --app windows only a 16 px page icon)
cat > "${MENUDIR}/js8map-spotter-map.desktop" <<MAP_EOF
[Desktop Entry]
Type=Application
Version=1.0
Name=JS8Map Spotter Map
Exec="${APPDIR}/JS8Map"
${ICON_LINE}
NoDisplay=true
StartupWMClass=127.0.0.1__ham_map.html
MAP_EOF
chmod +x "${MENUDIR}/js8map-spotter-map.desktop"

# desktop icon
if [ -d "${DESKDIR}" ]; then
    make_launcher "${DESKDIR}/JS8Map-Spotter.desktop"
    gio set "${DESKDIR}/JS8Map-Spotter.desktop" metadata::trusted true 2>/dev/null || true
fi

update-desktop-database "${MENUDIR}" 2>/dev/null || true

# --- prove what actually landed ---------------------------------------------
echo ""
echo "------------------------------------------------------------"
echo " Contents of ${APPDIR}"
echo "------------------------------------------------------------"
ls -1 "${APPDIR}"
echo "------------------------------------------------------------"
echo ""

COUNT=0
for f in $MAPFILES; do
    if [ -f "${APPDIR}/${f}" ]; then
        COUNT=$((COUNT + 1))
    fi
done

if [ "$COUNT" -eq 6 ] && [ -x "${APPDIR}/JS8Map" ] \
   && [ -f "${APPDIR}/build_canadian_db.py" ]; then
    echo "DONE. JS8Map Spotter is installed and all six map files are beside it."
    echo ""
    echo "Start it from the applications menu, from the desktop icon,"
    echo "or by running:  ${APPDIR}/JS8Map"
else
    echo "WARNING: the install finished but the folder above does not look right."
fi
echo ""
